# Bundle update guide

This repo uses a ZIP bundle only as a convenient bootstrap/update mechanism. Git history remains the backup and review trail.

## Bundle structure

```text
FURSA_BOOTSTRAP_BUNDLE.zip
├── manifest.json
└── payload/
    ├── README.md
    ├── docs/ENGINEERING_SOURCE_OF_TRUTH.md
    └── ...
```

`manifest.json` has:

- `replace`: exact repository-relative file paths that should be created or overwritten by matching files under `payload/`.
- `delete`: exact repository-relative file paths to delete. Keep this list empty unless a removal is intentional.

The workflow rejects paths outside the repo, Git internals, payload symlinks, manifest/payload mismatches, self-replacement of the ZIP, and replacement or deletion of the updater workflow. It never deletes files merely because they are absent from a bundle. Files not listed in `replace` or `delete` remain untouched.

To remove an obsolete file in a future bundle, add its path to `manifest.delete` and make sure it is not also listed in `manifest.replace`. GitHub Actions commits the changes on the branch that received the bundle; check the Actions run and commit after each application.
